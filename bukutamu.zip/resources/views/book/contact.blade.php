<x-home-layout title="Contact">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-6 mx-auto">
                <h2>Contact</h2>
                <div class="p-4 rounded bg-white shadow">
                    <ul>
                        <li>Email : kantahsubang@gmail.com</li>
                        <li>Telepon : (0260) 411025</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

</x-home-layout>
