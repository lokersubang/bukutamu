<x-home-layout>
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-6 mx-auto">
                <h2>About</h2>
                <div class="p-4 rounded bg-white shadow">
                    <p>Aplikasi ini digunakan untuk merekap tamu yang datang ke Kantor Pertanahan Kabupaten Subang
                        setiap harinya.</p>
                </div>
            </div>
        </div>
    </div>
</x-home-layout>
