    <x-home-layout>
        <h2>Dashboard</h2>
    </x-home-layout>
