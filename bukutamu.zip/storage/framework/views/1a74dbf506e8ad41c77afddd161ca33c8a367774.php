<?php if (isset($component)) { $__componentOriginal501e81491cdd9b61e2d9ba717a17361860b8d597 = $component; } ?>
<?php $component = App\View\Components\HomeLayout::resolve(['title' => 'Data Buku Tamu'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HomeLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-12">

                <h2>Data Buku Tamu</h2>
                <div class="p-3 rounded bg-white shadow-sm">
                    <form method="post" action="<?php echo e(route('buku.index')); ?>"
                        class="d-none d-sm-inline-block form-inline mr-auto  my-2 my-md-0 mw-100 navbar-search">
                        <?php echo csrf_field(); ?>
                        <div class="input-group mb-3">
                            <input type="text" class="form-control bg-light border-0 small" name="cari"
                                placeholder="Cari...">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                    <?php if(session()->has('flash')): ?>
                        <div class="alert alert-warning col-md-6 alert-dismissible fade show" role="alert">
                            Buku tamu berhasil di <strong> <?php echo e(session()->get('flash')); ?>

                            </strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-bordered " id="dataTable">
                            <thead class="bg-dark text-white">
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>Alamat</th>
                                    <th>Keperluan</th>
                                    <th>Tanggal</th>
                                    <th>Foto</th>
                                    <th>Setting</th>
                                </tr>
                            </thead>

                            <tbody>

                                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($books->firstItem() + $key); ?></td>
                                        <td><?php echo e($book->nama); ?></td>
                                        <td><?php echo e($book->alamat); ?></td>
                                        <td><?php echo e($book->tujuan); ?></td>
                                        <td><?php echo e($book->created_at->toDateTimeString()); ?> WIB</td>
                                        <td><?php echo e($book->gambar); ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-sm btn-danger dropdown-toggle"
                                                    data-toggle="dropdown" aria-expanded="false">
                                                    Opsi
                                                </button>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('buku.edit', $book->id)); ?>">Edit</a>
                                                    <form method="post"
                                                        action="<?php echo e(route('buku.destroy', $book->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button class="dropdown-item" type="submit"
                                                            onclick="return confirm('Yakin mau dihapus?')">Hapus</button>
                                                    </form>

                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <div class="mt-1">
                        <?php echo e($books->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal501e81491cdd9b61e2d9ba717a17361860b8d597)): ?>
<?php $component = $__componentOriginal501e81491cdd9b61e2d9ba717a17361860b8d597; ?>
<?php unset($__componentOriginal501e81491cdd9b61e2d9ba717a17361860b8d597); ?>
<?php endif; ?>
<?php /**PATH E:\Project\bukutamu\resources\views/admin/index.blade.php ENDPATH**/ ?>